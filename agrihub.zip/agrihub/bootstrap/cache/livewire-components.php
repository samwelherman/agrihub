<?php return array (
  'contact' => 'App\\Http\\Livewire\\Contact',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'iorder' => 'App\\Http\\Livewire\\Iorder',
  'manage' => 'App\\Http\\Livewire\\Manage',
);