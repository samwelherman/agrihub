  <!-- General JS Scripts -->
  <script src="<?php echo e(url('assets/js/app.min.js')); ?>"></script>
  <!-- JS Libraies -->
  <script src="<?php echo e(url('assets/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo e(url('assets/js/page/index.js')); ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo e(url('assets/js/scripts.js')); ?>"></script>
  
  <script src="<?php echo e(url('assets/bundles/prism/prism.js')); ?>"></script>
  <!-- Custom JS File -->
  <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
  <script src="<?php echo e(url('assets/bundles/select2/dist/js/select2.full.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/bundles/jquery-selectric/jquery.selectric.min.js"')); ?>"></script>
 
  <script src="<?php echo e(url('assets/bundles/sweetalert/sweetalert.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/page/sweetalert.js')); ?>"></script>
 
  <?php /**PATH /opt/lampp/htdocs/agrihub/resources/views/layouts/script.blade.php ENDPATH**/ ?>